module.exports = {
  MONGOURI:
    "mongodb+srv://avijit:xwQAT14RwVIm8Umg@cluster0.5ctckqn.mongodb.net/?retryWrites=true&w=majority",
  TOKEN_JWT_SECRET: "efofjefkfind123nfuck9449enjoy",
};
